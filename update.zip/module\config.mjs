export const IMPERIUMNIHILUS = {};

export const CONST = {
    SYSTEM_ID: "imperiumnihilus",
}
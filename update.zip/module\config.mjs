export const STARLINK = {};

export const CONST = {
    SYSTEM_ID: "starlink",
}
import Ship from "./actor/ship.mjs";
import Character from "./actor/character.mjs"

export const actor = {
    "Ship": Ship,
    "Character": Character
};

export const item = {}